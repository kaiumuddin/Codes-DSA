// High Level Thinking -> Basic code
// 1. Expection -> 5 pass krle 5 4 3 2 1 print krbe
// 2. Faith -> chuto valuer jnno kaj krbe, 4 emne emne print hbe, kmne hbe janar drkr nai
// 3. Faith to Expectation Relationship

// Low Level Thinking -> Dry RUn, Stack -> Base Case