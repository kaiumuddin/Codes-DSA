
console.log(subset(30, [0, 3, 34, 4, 12, 5, 2], 6));