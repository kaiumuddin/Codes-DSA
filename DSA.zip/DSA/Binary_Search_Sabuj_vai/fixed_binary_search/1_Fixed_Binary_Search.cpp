#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    double x;
    cin >> x;

    double l = 0, r = x, m;

    // for (int i = 0; i < 100; i++)
    // {
    //     m = l + (r - l) / 2;

    //     if (x <= m * m)
    //     {
    //         r = m;
    //     }
    //     else
    //     {
    //         l = m;
    //     }
    // }

    for (int i = 0; i < 100; i++)
    {
        
    }

    cout << fixed << setprecision(6) << l << endl;
}

// 1 2 3 4 5 6 7 8 9 16 25 36 49 64