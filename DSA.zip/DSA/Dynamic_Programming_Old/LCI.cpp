#include <bits/stdc++.h>
using namespace std;

int lci(vector<int> nums)
{
    return max( lci()  )
}

int main()
{
    cout << lci({5, 8, 7, 1, 9}) << endl;

    return 0;
}