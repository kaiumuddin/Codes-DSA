// O(1) - Constant Time Complexity: This means that the algorithm takes the same amount of time to execute regardless of the input size.This is the best case scenario, but it is not always possible.Here's an example of an algorithm with constant time complexity:;


function printFirstItem(arr) {
    console.log(arr[0]);
}
